"""
Simple try of the agent to add milk to Tesco basket.

@dev You need to add OPENAI_API_KEY to your environment variables.
@dev Requires Python 3.10
"""

import os
import sys
from pathlib import Path

# Ensure we load from .env file
from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent / '.env')

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import asyncio
from typing import Optional

from langchain_openai import ChatOpenAI

from browser_use import Agent, Controller
from browser_use.browser.browser import Browser, BrowserConfig


# Initialize browser with configuration
browser = Browser(
    config=BrowserConfig(
        headless=False,  # Set to True if you don't want to see the browser
    )
)

# Initialize controller
controller = Controller()

# Initialize LLM with explicit typing for Python 3.10 compatibility
llm: Optional[ChatOpenAI] = ChatOpenAI(model='gpt-4o')
agent = Agent(
    task='Open Chrome, if you see any Google popups, look for "Reject all" and click it. Then go to tesco.com, search for milk, and add the first semi-skimmed milk result to the basket. If login is required, login with the following credentials: email: kitchan98@gmail.com, password: VwWwZ6!TYM.s%9J',
    llm=llm,
    controller=controller,
    browser=browser,
)


async def main() -> None:
    try:
        await agent.run(max_steps=10)
        await browser.close()
        input('Press Enter to continue...')
    except Exception as e:
        print(f"An error occurred: {e}")
        await browser.close()


if __name__ == '__main__':
    asyncio.run(main()) 