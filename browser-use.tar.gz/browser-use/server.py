from flask import Flask, request, jsonify
from flask_cors import CORS
import asyncio
import os
from typing import Optional
from langchain_openai import ChatOpenAI
from browser_use import Agent, Controller
from browser_use.browser.browser import Browser, BrowserConfig

app = Flask(__name__)
CORS(app)

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy'})

@app.route('/automate', methods=['POST'])
def automate_tesco():
    try:
        # Verify authorization
        auth_header = request.headers.get('Authorization')
        if not auth_header or auth_header != f"Bearer {os.environ.get('AUTOMATION_SERVER_KEY')}":
            return jsonify({'error': 'Unauthorized'}), 401

        data = request.json
        ingredients = data.get('ingredients')
        credentials = data.get('credentials')

        if not ingredients or not credentials:
            return jsonify({'error': 'Missing ingredients or credentials'}), 400

        async def run_automation():
            try:
                # Initialize browser with configuration
                browser = Browser(
                    config=BrowserConfig(
                        headless=True,  # Run headless on server
                    )
                )

                # Initialize controller
                controller = Controller()

                # Initialize LLM
                llm: Optional[ChatOpenAI] = ChatOpenAI(
                    model='gpt-4',
                    temperature=0
                )
                
                # Create the task prompt
                task = f'''Go to tesco.com and add these ingredients to the basket. Follow these steps exactly:

1. Go to tesco.com
2. If you see any cookie/privacy popups, click "Reject all"
3. If login is required, use these credentials:
   email: {credentials['email']}
   password: {credentials['password']}

For each ingredient, follow these exact steps:
1. Look for the search input at the top of the page (it usually says "Search" or has a magnifying glass icon)
2. Click to focus the search input
3. If there's any existing text, clear it first
4. Type the exact search term provided
5. Press Enter to search
6. Wait for search results to load
7. Look through the results to find a product matching the full description
8. Click on the matching product
9. Set the correct quantity
10. Click the "Add" button
11. Wait for the "Added" confirmation before proceeding to next ingredient

Here are the ingredients:
{chr(10).join(f"• Search for '{ing['searchTerm']}' to find: {ing['fullDescription']}" for ing in ingredients)}

Important notes:
- The search box is usually at the top of the page with placeholder text "Search" or a magnifying glass icon
- Make sure you're typing in the search input, not clicking other buttons
- For fresh items, prefer loose/individual items where possible
- If exact match isn't available, pick the closest alternative
- Double-check quantities before adding to basket
- Wait for each "Add" action to complete before moving to the next ingredient'''

                agent = Agent(
                    task=task,
                    llm=llm,
                    controller=controller,
                    browser=browser,
                )

                await agent.run(max_steps=len(ingredients) * 5 + 5)
                await browser.close()
                return True
            except Exception as e:
                print(f"Automation error: {str(e)}")
                await browser.close()
                return False

        # Run the automation
        success = asyncio.run(run_automation())
        
        if success:
            return jsonify({'message': 'Automation completed successfully'})
        else:
            return jsonify({'error': 'Automation failed'}), 500

    except Exception as e:
        print(f"Server error: {str(e)}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Use environment variables or defaults
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port) 